from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from Crypto.Random import get_random_bytes

# Générer une clé AES (256 bits)
def generate_key():
    return get_random_bytes(32)  # 32 bytes = 256 bits

# Chiffrer un message
def encrypt_message(message, key):
    iv = get_random_bytes(16)  # Vecteur d'initialisation (16 bytes pour AES)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    message_pad = pad(message.encode('utf-8'), AES.block_size)
    ciphertext = cipher.encrypt(message_pad)
    return iv + ciphertext  # Concaténer IV et texte chiffré

# Déchiffrer un message
def decrypt_message(ciphertext, key):
    iv = ciphertext[:16]  # Extraire l'IV
    ciphertext = ciphertext[16:]  # Extraire le texte chiffré
    cipher = AES.new(key, AES.MODE_CBC, iv)
    message_pad = cipher.decrypt(ciphertext)
    message = unpad(message_pad, AES.block_size)
    return message.decode('utf-8')

# Exemple d'utilisation
if __name__ == "__main__":
    # Générer une clé
    key = generate_key()
    print("Clé AES (hex):", key.hex())
    
    # Message à chiffrer
    message = "Message secret !"
    print("Message original:", message)
    
    # Chiffrement
    ciphertext = encrypt_message(message, key)
    print("Message chiffré (hex):", ciphertext.hex())
    
    # Déchiffrement
    decrypted_message = decrypt_message(ciphertext, key)
    print("Message déchiffré:", decrypted_message)
    print(len("c29a66eceac8d929644c09d506b007409d6d20eb6f0e36aa38603f4ff1622e7f"))