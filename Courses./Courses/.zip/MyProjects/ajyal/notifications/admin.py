from django.contrib import admin
from .models import Notification,QuizNotification,CourseNotification


admin.site.register(Notification)


