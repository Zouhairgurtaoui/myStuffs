from django.contrib import admin
from .models import Course,Module,Filliere
# Register your models here.

admin.site.register(Filliere)

admin.site.register(Module)

